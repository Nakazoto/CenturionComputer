-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-----------H----H--X----X-----CCCCC----22222----0000-----0000------11----------
----------H----H----X-X-----C--------------2---0----0---0----0--1--1-----------
---------HHHHHH-----X------C----------22222---0----0---0----0-----1------------
--------H----H----X--X----C----------2-------0----0---0----0-----1-------------
-------H----H---X-----X---CCCCC-----222222----0000-----0000----1111------------
-------------------------------------------------------------------------------
--------------------------------------------------------- http://hxc2001.com --
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
                    HxC Floppy Emulator DOS Disk Image Browser
-------------------------------------------------------------------------------
                             Release 24 march 2013
-------------------------------------------------------------------------------

The HxC Floppy Emulator DOS Disk Image Browser is a simplified version of the HxC Floppy Emulator software.

With this tool you can easily browse any DOS formatted HFE files.
This version is designed to replace the VFD solution.

Avantages over the VFD solution :

- No driver installation needed.
- Support of 3 mode DOS floppy disk image (1KB sector size) (For PC98 based CNC machines).
- Support of special/custom DOS floppy disk image (2.5MB,4.5MB,6.78MB...)
- Compatible with Windows 2000 / XP / 7 / 10. 
- Ready to be used on non-windows systems (Mac, Linux,...) ! ;)
- Simple to use !

To use it :

Copy DosDiskBrowser.exe & libhxcfe.dll to the root of the SDCard/USB Stick with your DOS HFE files images.

Start DosDiskBrowser.exe. 
When lauched the software try to load the first HFE image found on the SDCard/USB Stick's root folder and display its content.

You can select the image with the disk selector buttons or by using the "Load Image" button.

To Get file(s) from the image disk :

-> You can get files from the image with the "Get Files" button.

To Add file(s) to the image disk :

-> You can add file(s) & subfolder(s) to the image by a drag&drop to the browser window.

Any modification done on the image are automatically saved when you use the disk selector buttons or when you use the "Close" button.

Jeff/HxC2001 
24/03/2013


HxC Floppy Emulator project.
https://hxc2001.com
(c)2006-2021 HxC2001
